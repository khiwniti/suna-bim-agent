'use client';

/**
 * Login Page
 *
 * Email/password and OAuth authentication
 * Shows warning for users who were using anonymous sessions
 */

import { useState, useEffect, Suspense } from 'react';
import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { nanoid } from 'nanoid';
import { useAuth } from '@/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { Logo } from '@/components/ui/Logo';
import { AlertTriangle, Loader2, UserX } from 'lucide-react';
import { useTranslation } from '@/i18n/provider';

function LoginForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { signIn, signInWithOAuth, loading, error: authError } = useAuth();
  const { t } = useTranslation();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [showAnonymousWarning, setShowAnonymousWarning] = useState(false);
  const [showGuestWarning, setShowGuestWarning] = useState(false);

  // Check if user was redirected from workspace (had anonymous session)
  useEffect(() => {
    const redirect = searchParams.get('redirect');
    const hadAnonymousSession = typeof window !== 'undefined' && localStorage.getItem('anonymousSessionId');
    if (redirect && hadAnonymousSession) {
      setShowAnonymousWarning(true);
    }
  }, [searchParams]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    try {
      await signIn(email, password);
      // Redirect to intended destination or dashboard
      const redirect = searchParams.get('redirect');
      router.push(redirect || '/dashboard');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Login failed');
    }
  };

  const handleOAuth = async (provider: 'google' | 'github') => {
    try {
      await signInWithOAuth(provider);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'OAuth login failed');
    }
  };

  const handleContinueAsGuest = () => {
    // Generate anonymous session ID and store it
    const anonymousId = nanoid();
    localStorage.setItem('anonymousSessionId', anonymousId);
    localStorage.setItem('anonymousSessionStarted', new Date().toISOString());

    // Redirect to workspace
    const redirect = searchParams.get('redirect');
    router.push(redirect || '/');
  };

  return (
    <Card className="w-full max-w-md border-border bg-card/80 backdrop-blur">
      <CardHeader className="text-center">
        {/* Anonymous Session Warning Banner */}
        {showAnonymousWarning && (
          <div className="mb-4 rounded-lg bg-warning/10 border border-warning/30 p-4 text-left">
            <div className="flex items-start gap-3">
              <AlertTriangle className="h-5 w-5 text-warning flex-shrink-0 mt-0.5" />
              <div>
                <h4 className="font-semibold text-warning text-sm">{t('auth.anonymous.warningTitle')}</h4>
                <p className="text-warning/80 text-xs mt-1">
                  {t('auth.anonymous.warningDescription')}
                </p>
              </div>
            </div>
          </div>
        )}

        <div className="mx-auto mb-4">
          <Logo size="lg" showText={false} />
        </div>
        <CardTitle className="text-2xl text-foreground">{t('auth.login.title')}</CardTitle>
        <CardDescription className="text-muted-foreground">
          {t('auth.login.subtitle')}
        </CardDescription>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* OAuth Buttons */}
        <div className="grid grid-cols-2 gap-3">
          <Button
            type="button"
            variant="outline"
            className="border-border bg-card/50 text-foreground hover:bg-muted"
            onClick={() => handleOAuth('google')}
            disabled={loading}
          >
            <svg className="mr-2 h-4 w-4" viewBox="0 0 24 24">
              <path fill="currentColor" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
              <path fill="currentColor" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
              <path fill="currentColor" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
              <path fill="currentColor" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
            </svg>
            {t('auth.oauth.google')}
          </Button>
          <Button
            type="button"
            variant="outline"
            className="border-border bg-card/50 text-foreground hover:bg-muted"
            onClick={() => handleOAuth('github')}
            disabled={loading}
          >
            <svg className="mr-2 h-4 w-4" fill="currentColor" viewBox="0 0 24 24">
              <path d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z"/>
            </svg>
            {t('auth.oauth.github')}
          </Button>
        </div>

        <div className="relative">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-border" />
          </div>
          <div className="relative flex justify-center text-sm">
            <span className="bg-card px-2 text-muted-foreground">{t('auth.login.orContinueWithEmail')}</span>
          </div>
        </div>

        {/* Email/Password Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="email" className="block text-sm font-medium text-foreground">
              {t('auth.login.email')}
            </label>
            <input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="mt-1 block w-full rounded-md border border-input bg-card px-3 py-2 text-foreground placeholder-muted-foreground focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
              placeholder={t('auth.login.emailPlaceholder')}
              required
            />
          </div>

          <div>
            <label htmlFor="password" className="block text-sm font-medium text-foreground">
              {t('auth.login.password')}
            </label>
            <input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="mt-1 block w-full rounded-md border border-input bg-card px-3 py-2 text-foreground placeholder-muted-foreground focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
              placeholder={t('auth.login.passwordPlaceholder')}
              required
            />
          </div>

          {(error || authError) && (
            <div className="rounded-md bg-destructive/10 p-3 text-sm text-destructive">
              {error || (authError instanceof Error ? authError.message : authError)}
            </div>
          )}

          <Button
            type="submit"
            className="w-full bg-primary hover:bg-primary/90"
            disabled={loading}
          >
            {loading ? t('auth.login.submitting') : t('auth.login.submit')}
          </Button>
        </form>

        <div className="text-center text-sm">
          <Link href="/auth/forgot-password" className="text-primary hover:text-primary/80">
            {t('auth.login.forgotPassword')}
          </Link>
        </div>

        {/* Continue as Guest Section */}
        <div className="relative">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-border" />
          </div>
          <div className="relative flex justify-center text-sm">
            <span className="bg-card px-2 text-muted-foreground">{t('auth.login.or')}</span>
          </div>
        </div>

        {showGuestWarning ? (
          <div className="rounded-lg bg-warning/10 border border-warning/30 p-4">
            <div className="flex items-start gap-3">
              <AlertTriangle className="h-5 w-5 text-warning flex-shrink-0 mt-0.5" />
              <div className="flex-1">
                <h4 className="font-semibold text-warning text-sm">{t('auth.guest.warningTitle')}</h4>
                <p className="text-warning/80 text-xs mt-1">
                  {t('auth.guest.warningDescription')}
                </p>
                <div className="flex gap-2 mt-3">
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    className="border-warning/50 text-warning hover:bg-warning/10"
                    onClick={() => setShowGuestWarning(false)}
                  >
                    {t('auth.guest.cancel')}
                  </Button>
                  <Button
                    type="button"
                    size="sm"
                    className="bg-warning hover:bg-warning/90 text-warning-foreground"
                    onClick={handleContinueAsGuest}
                  >
                    {t('auth.guest.understand')}
                  </Button>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <Button
            type="button"
            variant="ghost"
            className="w-full text-muted-foreground hover:text-foreground hover:bg-muted"
            onClick={() => setShowGuestWarning(true)}
          >
            <UserX className="mr-2 h-4 w-4" />
            {t('auth.guest.continueAsGuest')}
          </Button>
        )}
      </CardContent>

      <CardFooter className="justify-center border-t border-border pt-6">
        <p className="text-sm text-muted-foreground">
          {t('auth.login.noAccount')}{' '}
          <Link href="/auth/signup" className="text-primary hover:text-primary/80">
            {t('auth.login.signUpLink')}
          </Link>
        </p>
      </CardFooter>
    </Card>
  );
}

function LoginLoading() {
  return (
    <div className="w-full max-w-md flex items-center justify-center p-8">
      <Loader2 className="h-8 w-8 animate-spin text-primary" />
    </div>
  );
}

export default function LoginPage() {
  return (
    <Suspense fallback={<LoginLoading />}>
      <LoginForm />
    </Suspense>
  );
}
